import streamlit as st
import pandas as pd
import plotly.express as px
from sklearn.linear_model import LinearRegression
import numpy as np

# Charger et préparer les données
@st.cache(allow_output_mutation=True)
def load_data():
    data = pd.read_csv('prix-carburants.csv', sep=';')
    data[['Latitude', 'Longitude']] = data['geom'].str.split(',', expand=True)
    data['Latitude'] = pd.to_numeric(data['Latitude'], errors='coerce')
    data['Longitude'] = pd.to_numeric(data['Longitude'], errors='coerce')
    data['Mise à jour des prix'] = pd.to_datetime(data['Mise à jour des prix'], errors='coerce')
    data['Année'] = data['Mise à jour des prix'].dt.year
    return data[data['Région'] == 'Île-de-France' & data['Carburant'] == 'Gazole']

data = load_data()

# Calcul des prix moyens par année
prix_moyens_annuels = data.groupby('Année')['Prix'].mean().reset_index()

# Construction du modèle de régression linéaire
model = LinearRegression()
X = prix_moyens_annuels[['Année']]
y = prix_moyens_annuels['Prix']
model.fit(X, y)

# Interface utilisateur pour prédiction
st.title('Prédiction des Prix du Gazole')
année_choisie = st.number_input('Choisir une année future:', min_value=int(X['Année'].max()) + 1, max_value=2030, value=int(X['Année'].max()) + 1)

if st.button('Prédire le Prix'):
    predicted_price = model.predict(np.array([[année_choisie]]))[0]
    st.write(f'Le prix prédit du Gazole pour l\'année {année_choisie} est de {predicted_price:.2f} €.')

# Visualisation des stations-service pour le gazole
st.title('Carte des Stations-Service en Île-de-France pour Gazole')
fig = px.scatter_mapbox(data,
                        lat='Latitude',
                        lon='Longitude',
                        hover_name='ville',
                        hover_data={'Prix': True, 'Latitude': False, 'Longitude': False},
                        color='Prix',
                        color_continuous_scale=px.colors.sequential.Viridis,
                        zoom=9,
                        center={"lat": 48.8566, "lon": 2.3522"},
                        title='Prix du Gazole par Station')
st.plotly_chart(fig)
